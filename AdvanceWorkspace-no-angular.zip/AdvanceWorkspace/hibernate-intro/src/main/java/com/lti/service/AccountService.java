package com.lti.service;

import java.sql.Date;
import java.util.List;

import com.lti.dao.AccountStatementDao;
import com.lti.dao.GenericDao;
import com.lti.entity.Account;
import com.lti.entity.Statement;
import com.sun.corba.se.spi.orbutil.fsm.State;

//service classes
public class AccountService {

	public void openAccount(String name, String type, double initialBalance)
	{	
		double openbalance=2000;
		
		
		if(initialBalance>=openbalance) 
		{
			Account a=new Account();
			a.setAccountName(name);
			a.setAccountType(type);
		a.setAccountBalance(initialBalance);
		GenericDao dao=new GenericDao();
		dao.save(a);
		}
		else
		System.out.println("APPLICATION REJECTED...");
		System.out.println("===========================");
	}
	
	public void withdraw(long accountNo,double amount)
	{
		GenericDao dao=new GenericDao();
		Account a=dao.find(Account.class, accountNo);
		if(amount>a.getAccountBalance())
			System.out.println("sry..INSUFFICIENT BALANCE\n"+"You have : "+a.getAccountBalance());
		else
		{
				/*double remaining=a.getAccountBalance();
				remaining-=amount;*/
				
			a.setAccountBalance(a.getAccountBalance()-amount);
			/*Statement st=new Statement();
			st.setAccountNo(accountNo);
			st.setDate(new Date());
			
			*/
			dao.save(a);
			 
		}	
	}
	
	public void transfer(long fromacno,long toacno, double amount)
	{
		GenericDao dao=new GenericDao();
		Account a=dao.find(Account.class, fromacno);

		if(amount>a.getAccountBalance())
			System.out.println("sry..INSUFFICIENT BALANCE\n"+"You have : "+a.getAccountBalance());
	
	else
	{	
		 a=dao.find(Account.class, fromacno);
		 Account a1=dao.find(Account.class, toacno);
			
		a.setAccountBalance(a.getAccountBalance()-amount);
		a1.setAccountBalance(a.getAccountBalance()+amount);

		dao.save(a);
		dao.save(a1);
		System.out.println("after saving both");
	}
	}

	public double checkBalance(long accountNo)
	{
		GenericDao dao=new GenericDao();
		Account a=dao.find(Account.class, accountNo);
		System.out.println("--------------------");

		return a.getAccountBalance();
	}
	public List<Statement> miniStatement(long acno) {
		AccountStatementDao dao = new AccountStatementDao();
		return dao.fetchStatementByAccount(acno);
	}
}

