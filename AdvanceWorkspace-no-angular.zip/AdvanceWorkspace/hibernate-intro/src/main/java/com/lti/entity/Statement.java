package com.lti.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_STATEMENT")
public class Statement {
	@Id
	@GeneratedValue
	private int transactionNo;
	@Column(name = "date_and_time")
	private Date Date;
	private String transactionType;
	private int transactionAmount;
	
	@ManyToOne
	@JoinColumn(name="accountNo")
	private Account accountNo;

	public Date getDate() {
		return Date;
	}
	

	public int getTransactionNo() {
		return transactionNo;
	}


	public void setTransactionNo(int transactionNo) {
		this.transactionNo = transactionNo;
	}


	public void setDate(Date date) {
		Date = date;
	}
	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public int getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Account getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Account accountNo) {
		this.accountNo = accountNo;
	}
	
	
}
