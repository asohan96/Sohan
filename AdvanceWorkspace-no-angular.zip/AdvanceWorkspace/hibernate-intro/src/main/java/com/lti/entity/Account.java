package com.lti.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="TBL_ACCOUNT")
public class Account {
	@Id
	@GeneratedValue
	
private long accountNo;
private String accountName;
private String accountType;
private double accountBalance;

@OneToMany(mappedBy="accountNo", cascade=CascadeType.ALL) 
private Set<Statement> statements;

public String getAccountName() {
	return accountName;
}

public void setAccountName(String accountName) {
	this.accountName = accountName;
}

public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}

public double getAccountBalance() {
	return accountBalance;
}

public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}

public Set<Statement> getStatements() {
	return statements;
}

public void setStatements(Set<Statement> statements) {
	this.statements = statements;
}




}
