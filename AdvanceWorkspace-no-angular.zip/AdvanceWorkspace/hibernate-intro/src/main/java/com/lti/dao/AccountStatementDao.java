package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.entity.Statement;

public class AccountStatementDao extends GenericDao {

	public List<Statement> fetchStatementByAccount(long accountNo) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("oracle-unit");
			em = emf.createEntityManager();
			String jpql = "select s from Statement as s where s.account.accountNo = ?1 order by s.date desc";
			return em.createQuery(jpql).setParameter(1, accountNo).setMaxResults(5).getResultList();
		} finally {
			em.close();
			emf.close();
		}
	}
}
