package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.entity.Actor;

import javax.persistence.Id;

public class GenericDao { // CammonDao, BaseDao, SabkDao
	EntityManagerFactory emf = null;
	EntityManager em = null;
	EntityTransaction tx = null;

	
//Insertion of data in table using merge method(INSERT QUERY, UPDATE QUERY)
	public void save(Object obj) {

		try {
			emf = Persistence.createEntityManagerFactory("oracle-unit");

			em = emf.createEntityManager();

			tx = em.getTransaction();
			tx.begin();

			// em.persist(obj);
			em.merge(obj); // merge method can be used for insert for update both

			tx.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			em.close();

			emf.close();
		}
	}
	//function for fetching data of table based on PK(down casting)
	public <T> T find(Class<T> clazz, Object pk) {
		try {
			emf = Persistence.createEntityManagerFactory("oracle-unit");
			em = emf.createEntityManager();
			T t = em.find(clazz, pk);
			return t;
		} finally {
			em.close();
			emf.close();
		}

	}
	
	//function for fetching all data of the table 
	public <T>List<T> fetchAll(Class<T> clazz) {
		try {
			emf = Persistence.createEntityManagerFactory("oracle-unit");
			em = emf.createEntityManager();
			String jpql="select obj from " + clazz.getName() + " as obj";
			return em.createQuery(jpql,clazz).getResultList();
			} finally {
			em.close();
			emf.close();
		}	
	}		
}
