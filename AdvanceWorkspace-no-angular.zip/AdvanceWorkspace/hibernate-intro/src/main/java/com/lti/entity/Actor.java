package com.lti.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_ACTOR")
public class Actor {
	
	@Id // pk
	@GeneratedValue // auto generate pk
	@Column(name = "ACTOR_ID") // In table id will be ACTOR_ID
    private int id;
	private String stageName;
	private String realName;
	private int noOfMovies;
	private int hitMovies;
	private int flopMovies;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStageName() {
		return stageName;
	}

	public void setStageName(String stageName) {
		this.stageName = stageName;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public int getNoOfMovies() {
		return noOfMovies;
	}

	public void setNoOfMovies(int noOfMovies) {
		this.noOfMovies = noOfMovies;
	}

	public int getHitMovies() {
		return hitMovies;
	}

	public void setHitMovies(int hitMovies) {
		this.hitMovies = hitMovies;
	}

	public int getFlopMovies() {
		return flopMovies;
	}

	public void setFlopMovies(int flopMovies) {
		this.flopMovies = flopMovies;
	}

}
