package com.lti.dao;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.entity.Actor;

// In hibernate select query is hard coded and rest are taken cre by hibernate itself

public class ActorDao {
	public void add(Actor actor) {
		// Step1:create obtain EntityManagerFactory object
		// During this step meta inf persistence.xml will be read
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracle-unit");
		// step2: create/obtain entirty manager object
		// During this step a connection will be opened to the DB
		EntityManager em = emf.createEntityManager();
		// step3: Start participate in a transaction.
		// hibernate doesnt auto commit we need to take care of it.
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		// Now we can /insert/update/delete/select what ever we want
		em.persist(actor);// persist method generate insert query for us.

		tx.commit();
		// below code in a finally block

		em.close();
		emf.close();

	}

	public Actor fetch(int actorId) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracle-unit");
		EntityManager em = emf.createEntityManager();
		Actor a = em.find(Actor.class, actorId);// find method generates select query
		em.close();
		emf.close();
		return a;

	}

	public List<Actor> fetchAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracle-unit");
		EntityManager em = emf.createEntityManager();
	   String jpql="select a from Actor as a";
	   Query q = em.createQuery(jpql);
	   List<Actor> actors =q.getResultList();
		em.close();
		emf.close();
		return actors;
	}
	/*public List<Actor> fetchByMovies(int noOfMovies) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracle-unit");
		EntityManager em = emf.createEntityManager();
	   String jpql="select a from Actor as a where a.noOfMovies >= ?";
	   Query q = em.createQuery(jpql);
	   q.setParameter(1, noOfMovies);
	   List<Actor> actors =q.getResultList();
		em.close();
		emf.close();
		return actors;
	}
*/
	public List<Actor> fetchByFirstLetter(String letter) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("oracle-unit");
		EntityManager em = emf.createEntityManager();
	   String jpql="select a from Actor as a where a.realName like '?%'";
	   Query q = em.createQuery(jpql);
	   String startingLetter=letter;
	   startingLetter+='%';
	   q.setParameter(1, startingLetter);
	   List<Actor> actors =q.getResultList();
		em.close();
		emf.close();
		return actors;
	}
}
