package com.lti.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.lti.dao.ActorDao;
import com.lti.entity.Actor;

public class ActorTest {
	

	/*@Test
	public void addTest() {
		Actor actor=new Actor();
		actor.setStageName("SRK");
		actor.setRealName("Shah Rukh Khan");
		actor.setNoOfMovies(99999999);
		actor.setHitMovies(9999);
		actor.setFlopMovies(2);
		
	
		
		ActorDao dao=new ActorDao();
		dao.add(actor);		
	}
	@Test
	public void fetch() {
		ActorDao dao=new ActorDao();
		Actor a=dao.fetch(42);
		assertNotNull(a);	
		////		not to write syso over here in TDD....use assert...
		System.out.println(a.getRealName());
		System.out.println(a.getStageName());
		System.out.println(a.getHitMovies());
		System.out.println(a.getFlopMovies());
	}
	@Test
	public void fetchAll() {
		ActorDao dao=new ActorDao();
		List<Actor> actors=dao.fetchAll();
		assertNotNull(actors);
		assertEquals(13, actors.size());
		for (Actor actor : actors) {
			System.out.println("----------------------------");
			System.out.println(actor.getRealName());
			System.out.println(actor.getStageName());
			System.out.println(actor.getNoOfMovies());
			System.out.println(actor.getFlopMovies());
			System.out.println(actor.getHitMovies());
			
		}
		}*/
		/*@Test
		public void fetchByMovies() {
			ActorDao dao=new ActorDao();
			List<Actor> actors=dao.fetchByMovies(200);
			assertNotNull(actors);
			
			for (Actor actor : actors) {
				System.out.println("----------------------------");
				System.out.println(actor.getRealName());
				System.out.println(actor.getStageName());
				System.out.println(actor.getNoOfMovies());
				System.out.println(actor.getFlopMovies());
				System.out.println(actor.getHitMovies());
			}
			}*/
	@Test
	public void fetchByFirstLetter() {
		ActorDao dao=new ActorDao();
		List<Actor> actors=dao.fetchByFirstLetter("S");
		assertNotNull(actors);
		
		for (Actor actor : actors) {
			System.out.println("----------------------------");
			System.out.println(actor.getRealName());
			System.out.println(actor.getStageName());
			System.out.println(actor.getNoOfMovies());
			System.out.println(actor.getFlopMovies());
			System.out.println(actor.getHitMovies());
			
		}
		}
	
	


}
