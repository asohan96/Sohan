package com.lti.test;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.lti.dao.GenericDao;
import com.lti.entity.Album;
import com.lti.entity.Department;
import com.lti.entity.Employee;
import com.lti.entity.Song;

public class DeptEmpTest {

	
	@Test
	public void addNewDepartmentAlongWithSomeEmployeesTest() {
		Department department = new Department();
		department.setDeptName("IT");
		department.setLocation("Andheri");

		Department department1 = new Department();
		department1.setDeptName("HR");
		department1.setLocation("Mahape");

		Department department2 = new Department();
		department2.setDeptName("Support");
		department2.setLocation("Aroli");

		Employee emp1 = new Employee();
		emp1.setEmpName("Sohan");
		emp1.setSalary(25000);
		emp1.setDepartment(department);

		Employee emp2 = new Employee();
		emp2.setEmpName("Sohan");
		emp2.setSalary(25000);
		emp2.setDepartment(department);

		Employee emp3 = new Employee();
		emp3.setEmpName("Tanuja");
		emp3.setSalary(30000);
		emp3.setDepartment(department1);

		Set<Employee> employees = new HashSet<Employee>();

		employees.add(emp1);
		employees.add(emp2);

		Set<Employee> employees1 = new HashSet<Employee>();
		employees1.add(emp3);

		department.setEmployees(employees);
		department1.setEmployees(employees1);

		GenericDao dao = new GenericDao();
		dao.save(department);
		dao.save(department1); // insertion query through merge knwn as merge

	}
}
