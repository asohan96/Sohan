package com.lti.test;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.lti.dao.GenericDao;
import com.lti.entity.Album;
import com.lti.entity.Song;

public class AlbumSongTest {

	@Test
	public void addNewAlbumTest() {
		Album album1=new Album();
		album1.setAlbumName("Dhadkan");
		album1.setCopyright("T-series");
		GenericDao dao=new GenericDao();
		dao.save(album1);
	}
	@Test
	public void addNewSongToExistingAlbumTest() {
		GenericDao dao=new GenericDao();
		Album album1=dao.find(Album.class, 99);		// check whether 99 id is present or not if yes process ahead to add songs in it.
		
		Song song1=new Song();
		song1.setTitle("Badne lagi");
		song1.setDuration(150);
		song1.setAlbum(album1);
		
		Song song2=new Song();
		song2.setTitle("ghatne lagi");
		song2.setDuration(200);
		song2.setAlbum(album1);

		Song song3=new Song();
		song3.setTitle("mitne lagi");
		song3.setDuration(220);
		song3.setAlbum(album1);

		dao.save(song1);						//insertion query through merge knwn as merge
		dao.save(song2);							//insertion query through merge knwn as merge
		dao.save(song3);							//insertion query through merge knwn as merge
	}
	@Test
	public void addNewAlbumAlongWithSomeSongsTest() {
		Album album3=new Album();
		album3.setAlbumName("Java 755");
		album3.setCopyright("LTI-MAHAPE");
		
		Song song1=new Song();
		song1.setTitle("Hum Honge Kamyaab");
		song1.setDuration(200);
		song1.setAlbum(album3);
		
		Song song2=new Song();
		song2.setTitle("We Will Rock");
		song2.setDuration(200);
		song2.setAlbum(album3);
		
		Set<Song> songs =new HashSet<Song>();
		songs.add(song1);
		songs.add(song2);
		album3.setSongs(songs);
		
		GenericDao dao=new GenericDao();
		dao.save(album3);						//insertion query through merge knwn as merge
		
}
}
