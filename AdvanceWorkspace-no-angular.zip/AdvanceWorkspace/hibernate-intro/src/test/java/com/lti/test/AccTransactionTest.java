package com.lti.test;

import java.util.Set;
import java.util.List;
import com.lti.entity.Statement;
import org.junit.Test;

import com.lti.dao.GenericDao;
/*import com.lti.entity.Account;*/
import com.lti.service.AccountService;


public class AccTransactionTest {

	@Test
	public void openAccTest()
	{
		AccountService a1=new AccountService();
		a1.openAccount("tanay", "Saving", 10000);
		GenericDao dao = new GenericDao();
		dao.save(a1);
		
	}
	
	@Test
	public void withdrawTest()
	{
		AccountService a1=new AccountService();
		a1.withdraw(181, 2000);
		GenericDao dao = new GenericDao();
		dao.save(a1);
		
	}
	@Test
	public void transferTest()
	{
		AccountService a1=new AccountService();
		a1.transfer(181, 183, 5000);
		GenericDao dao = new GenericDao();
		dao.save(a1);
		
	}
	
	@Test
	public void checkBalanceTest()
	{
		AccountService a1=new AccountService();
		a1.checkBalance(183);
		GenericDao dao = new GenericDao();
		dao.save(a1);
		
	}
	@Test
	public void miniStatement() {
		AccountService acServ = new AccountService();
		List<Statement> statements = acServ.miniStatement(102);
		for (Statement statement : statements) {
			System.out.print("TxNo: "+ statement.getTransactionNo() +" \t");
			System.out.println("Amt: "+statement.getTransactionAmount());
		}
	}
}
