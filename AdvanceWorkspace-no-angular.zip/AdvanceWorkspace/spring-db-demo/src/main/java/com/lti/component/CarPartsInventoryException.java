package com.lti.component;

public class CarPartsInventoryException extends RuntimeException {

	public CarPartsInventoryException() {
		super();
		
	}

	public CarPartsInventoryException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public CarPartsInventoryException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public CarPartsInventoryException(String message) {
		super(message);
		
	}

	public CarPartsInventoryException(Throwable cause) {
		super(cause);
		
	}

}
