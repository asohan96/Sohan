package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.Customer1Dao;
import com.lti.dao.Customer2Dao;
import com.lti.entity.CustomerDetails;
import com.lti.entity.CustomerCredentials;
import com.lti.entity.CustomerDTO;

@Component("CustomerService")
public class CustomerService {
	@Autowired
	private Customer1Dao dao1;
	
	
	@Autowired
	private Customer2Dao dao2;
@Transactional	
public void addCustomer(CustomerDTO cust)
{	
	CustomerDetails cust1=new CustomerDetails();
	cust1.setName(cust.getName());
	cust1.setAge(cust.getAge());
	cust1.setEmail(cust.getEmail());
	dao1.add1(cust1);
	
	CustomerCredentials cust2=new CustomerCredentials();
	cust2.setUser(cust.getUser());
	cust2.setPassword(cust.getPassword());
	
	dao2.add(cust2);
}
}
