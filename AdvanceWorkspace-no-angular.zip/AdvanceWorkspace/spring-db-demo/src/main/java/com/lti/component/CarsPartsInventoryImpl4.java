package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;



@Component("CarsParts-4")
public class CarsPartsInventoryImpl4 implements CarsPartsInventory {
		//@Autowired		this annotations doesnt work for injecting enitity manager.
	
	@PersistenceContext
	private EntityManager entityManager;

	//enabling support for transactions
	//assuring function execution/transaction via completion and then commit	//	or else rollback and come out
	@Transactional			
	public void addNewPart(CarPart carPart) {
		entityManager.persist(carPart);

	}

	public List<CarPart> getAvailableParts() {
		String jpql="select a from CarPart as a";
		   Query q = entityManager.createQuery(jpql);
		   List<CarPart> carpart =q.getResultList();
			
			return carpart;
	}
	
	@Transactional
	public void updateStock(int partNo, int quantity) {
		CarPart c=entityManager.find(CarPart.class, partNo);
		c.setStock(quantity);
		entityManager.merge(c);
		
	}

}
