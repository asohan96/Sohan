package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component("CarsParts-1")
public class CarsPartsInventoryImpl1 implements CarsPartsInventory {

	public void addNewPart(CarPart carPart) {
		Connection conn=null;
		PreparedStatement stmt=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","stuser","sohan123");
			String sql="insert into TBL_CARPART values (?,?,?,?)";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, carPart.getPartNo());
			stmt.setInt(2, carPart.getStock());
			stmt.setString(3, carPart.getName());
			stmt.setString(4, carPart.getCarModel());
			stmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			
			throw new CarPartsInventoryException("Problem in addNewPart method",e);
		} finally {
			try {stmt.close();} catch (SQLException e) {}
			try {conn.close();} catch (Exception e) {}
			}
}

	public List<CarPart> getAvailableParts() {
		Connection conn = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","stuser","sohan123");
			String sql = "select partno, name, carmodel, stock from TBL_CARPART";
			rs = conn.createStatement().executeQuery(sql);
			
			List<CarPart> partList = new ArrayList<CarPart>();
			while(rs.next()) {
				CarPart carPart = new CarPart();
				carPart.setPartNo(rs.getInt(1));
				carPart.setName(rs.getString(2));
				carPart.setCarModel(rs.getString(3));
				carPart.setStock(rs.getInt(4));
				partList.add(carPart);
			}
			return partList;
			
		}	catch (SQLException | ClassNotFoundException e) { 
				throw new CarPartsInventoryException("Problem in getAvailableParts method", e);
		}	finally {
			try { conn.close(); } catch (Exception e) {}
	}
	}
	

	public void updateStock(int partNo, int quantity) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","stuser","sohan123");
			String sql = "update TBL_CARPART set stock = ? where partNo = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1,quantity);	
			stmt.setInt(2, partNo);
			stmt.executeUpdate();
			
		} 	catch (ClassNotFoundException | SQLException e) { 
			throw new CarPartsInventoryException("Problem in updateStock method", e);
		}	finally {
				try { stmt.close(); 
				} catch (SQLException e) { 
					throw new CarPartsInventoryException("Problem in closing stmt in updateStock method", e);
				}
				try { conn.close(); } catch (Exception e) { 
			
				}
		}
	}


}
