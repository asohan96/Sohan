package com.lti.component;

public class Customer2 {

}
