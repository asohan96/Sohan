package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("CarsParts-3")
public class CarsPartsInventoryImpl3 implements CarsPartsInventory {
	@Autowired
	@Qualifier("dataSource1")
	private DataSource dataSource;

	public void addNewPart(CarPart carPart) {
		/*
		 * Connection conn = null; PreparedStatement stmt = null; try { //
		 * Class.forName("oracle.jdbc.driver.OracleDriver"); //
		 * conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
		 * "stuser","sohan123"); conn = dataSource.getConnection();
		 */
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.update("insert into TBL_CARPART values (?,?,?,?)",
		carPart.getPartNo(),
		carPart.getStock(),
		carPart.getName(),
		carPart.getCarModel());

	}

	public List<CarPart> getAvailableParts() {
			JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
			String sql = "select partno, stock, name, carmodel from TBL_CARPART";
			
			return jdbcTemplate.query(sql, new CarPartRowMapper());	
//			List<CarPart> list=jdbcTemplate.query(sql, new CarPartRowMapper());
//			return list;
	}
	class CarPartRowMapper implements RowMapper<CarPart>
	{

		@Override
		public CarPart mapRow(ResultSet rs, int index) throws SQLException {
			CarPart carPart = new CarPart();
			carPart.setPartNo(rs.getInt(1));
			carPart.setStock(rs.getInt(2));
			carPart.setName(rs.getString(3));
			carPart.setCarModel(rs.getString(4));
			
			return carPart;
		}
		
	}
	public void updateStock(int partNo, int quantity) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "update TBL_CARPART set stock = ? where partNo = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, quantity);
			stmt.setInt(2, partNo);
			stmt.executeUpdate();

		} catch (SQLException e) {
			throw new CarPartsInventoryException("Problem in updateStock method", e);
		} finally {
			try {
				stmt.close();
			} catch (SQLException e) {
				throw new CarPartsInventoryException("Problem in closing stmt in updateStock method", e);
			}
			try {
				conn.close();
			} catch (Exception e) {

			}
		}
	}

}
