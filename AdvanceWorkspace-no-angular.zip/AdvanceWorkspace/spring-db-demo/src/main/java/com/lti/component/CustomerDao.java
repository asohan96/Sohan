package com.lti.component;

public class CustomerDao {

}
