package com.lti.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



import com.lti.entity.CustomerDTO;
import com.lti.service.CustomerService;

public class CustomerTest {
	@Test
	public void addCustomerTest() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CustomerService cs = (CustomerService) ctx.getBean("CustomerService");
		CustomerDTO cust = new CustomerDTO();//name age,email,user,pass
		cust.setName("Sohan");
		cust.setAge(22);
		cust.setEmail("sohan@gmail.com");
		cust.setUser("sohan96");
		cust.setPassword("sohan123");
		cs.addCustomer(cust);
	}

}
