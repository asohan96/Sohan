package com.lti.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarsPartsInventory;

public class SpringCarPartInventoryTest {

	@Test
	public void test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-1");
		CarPart cp = new CarPart();
		cp.setPartNo(12345);
		cp.setStock(50);
		cp.setName("Nut & Bolt");
		cp.setCarModel("Maruti 800");
		cpi.addNewPart(cp);
	}

	@Test
	public void carpart2test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-2");
		CarPart cp = new CarPart();
		cp.setPartNo(12345);
		cp.setStock(50);
		cp.setName("Tyres & Rim Size");
		cp.setCarModel("KTM 790");
		cpi.addNewPart(cp);
	}

	@Test
	public void carpart3test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-3");
		CarPart cp = new CarPart();
		cp.setPartNo(12345);
		cp.setStock(50);
		cp.setName("Tyres & Rim Size");
		cp.setCarModel("KTM 1290");
		cpi.addNewPart(cp);
	}

	@Test
	public void JbdcTemplateSelectTest() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-3");
		CarPart cp = new CarPart();
		/*
		 * cp.setPartNo(12345); cp.setStock(50); cp.setName("Tyres & Rim Size");
		 * cp.setCarModel("KTM 1290");
		 */
		List<CarPart> list = cpi.getAvailableParts();
		for (CarPart c : list) {
			System.out.println(c.getPartNo());
			System.out.println(c.getStock());
			System.out.println(c.getName());
			System.out.println(c.getCarModel());
		}
	}

	@Test
	public void Test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-4");
		CarPart cp = new CarPart();

		List<CarPart> list = cpi.getAvailableParts();
		for (CarPart c : list) {
			System.out.println(c.getPartNo());
			System.out.println(c.getStock());
			System.out.println(c.getName());
			System.out.println(c.getCarModel());
		}

	}
	
	
	@Test
	public void addcarpart4test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-4");
		CarPart cp = new CarPart();
		cp.setPartNo(690);
		cp.setStock(10);
		cp.setName("Head-lights");
		cp.setCarModel("Royal Enfield 350");
		cpi.addNewPart(cp);
	}
	
	
@Test
	public void updatecarpart4test() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		CarsPartsInventory cpi = (CarsPartsInventory) ctx.getBean("CarsParts-4");
		cpi.updateStock(690, 100);
	}
}
