package com.lti.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lti.dao.ProductDao;
import com.lti.entity.Product;
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int from = Integer.parseInt(request.getParameter("from"));
		int to = Integer.parseInt(request.getParameter("to"));
		
		ProductDao dao = new ProductDao();
		List<Product> list=dao.fetchProducts(from, to);
		
		ObjectMapper mapper = new ObjectMapper();	//code to generate JSON
		String json = mapper.writeValueAsString(list);
		
		//CORS header
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();
		out.write(json);
		
	}

}
