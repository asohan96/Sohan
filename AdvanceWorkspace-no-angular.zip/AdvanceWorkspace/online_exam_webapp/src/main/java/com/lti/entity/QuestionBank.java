package com.lti.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionBank {
	private Map<String, List<Question>> questionBank; // question with subject stored over here
	
	/*private list<Question> questionOnJava;
	private list<Question> questionOnPhp;
	private list<Question> questionOnAspnet;
	private list<Question> questionOnEnglish;
	private list<Question> questionOnJava-7;*/
	
	public QuestionBank() {
		questionBank=new HashMap<String, List<Question>>();
	}
	
	public void addNewSubject(String subject)
	{
		questionBank.put(subject, new ArrayList<Question>());			//<Question> has String question and <options> 
		
	}

	public void addNewQuestion(String subject,Question question)
	{
		List<Question> questions = questionBank.get(subject);		
		questions.add(question);									//question with options
		
	}
	
	public List<Question> getQuestionsFor(String subject)
	{
		return questionBank.get(subject);
		
		
	}
	
	
}
