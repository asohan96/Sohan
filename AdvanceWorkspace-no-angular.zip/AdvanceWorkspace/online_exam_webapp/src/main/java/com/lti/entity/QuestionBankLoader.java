package com.lti.entity;

import java.util.ArrayList;
import java.util.List;

public class QuestionBankLoader { // created to test sample questions

	public List<Question> loadQuestionsOnJava() {
		QuestionBank questionBank = new QuestionBank();
		questionBank.addNewSubject("Java");

		Question q = new Question();

		q.setQuestion("what is java?");													//1

		Option o1 = new Option();
		o1.setOption("Java ne kharab kiya...");
		o1.setRightAnswer(false); // if not given then ok...bcoz boolean's default is false

		Option o2 = new Option();
		o2.setOption("Java is a programming lang");
		o2.setRightAnswer(true);

		Option o3 = new Option();
		o3.setOption("Java is a database");
		o3.setRightAnswer(false);

		Option o4 = new Option();
		o4.setOption("Java is a scripting language");
		o4.setRightAnswer(false);
		List<Option> options = new ArrayList<Option>();
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		/////////////////////////////////////////////////////////////////////////////////////////
		q = new Question(); // New Question2
		q.setQuestion("what is the latest version of java?");						//2

		o1 = new Option();
		o1.setOption("10.0");
		o1.setRightAnswer(true);

		o2 = new Option();
		o2.setOption("z.0");

		o3 = new Option();
		o3.setOption("5.0");

		o4 = new Option();
		o4.setOption("11.0");
		
		options = new ArrayList<Option>();
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		/////////////////////////////////////////////////////////////////////////////////////////
		q = new Question(); // New Question3
		q.setQuestion("what is JVM?");									//3

		o1 = new Option();
		o1.setOption("java runtime ");

		o2 = new Option();
		o2.setOption("Java virtual  masian");
		o2.setRightAnswer(true);

		o3 = new Option();
		o3.setOption("Java is a database");

		o4 = new Option();
		o4.setOption("Java is a scripting language");
		
		options = new ArrayList<Option>();
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
/////////////////////////////////////////////////////////////////////////////////////////
		q = new Question(); // New Question4
		q.setQuestion("what is inheritence?");													//4

		o1 = new Option();
		o1.setOption("Parent  and child relationship");
		o1.setRightAnswer(true);

		o2 = new Option();
		o2.setOption("Java is a programming lang");

		o3 = new Option();
		o3.setOption("Java is a database");

		o4 = new Option();
		o4.setOption("Java is a scripting language");
		
		options = new ArrayList<Option>();
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
/////////////////////////////////////////////////////////////////////////////////////////
		q = new Question(); // New Question5
		q.setQuestion("what is the first version of java?");										//5

		o1 = new Option();
		o1.setOption("10.0.");

		o2 = new Option();
		o2.setOption("6.0");

		o3 = new Option();
		o3.setOption("1.0");
		o3.setRightAnswer(true);

		o4 = new Option();
		o4.setOption("0.1");

		options = new ArrayList<Option>();
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		return questionBank.getQuestionsFor("Java");

	}
}
