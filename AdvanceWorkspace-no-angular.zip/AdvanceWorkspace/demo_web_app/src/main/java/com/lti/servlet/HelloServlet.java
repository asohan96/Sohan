package com.lti.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet(urlPatterns = { "/hello.exe", "/hi.exe", "/welcome.exe" },loadOnStartup=1)
public class HelloServlet extends HttpServlet {
	@Override
	public void init() throws ServletException {

		System.out.println("You  are in Init");
	}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	System.out.println("you are in  doGet");
	
}
	/*protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("you are in  doPost");
	}
*/
	@Override
	public void destroy() {

		System.out.println("Destroy");
	}

}
