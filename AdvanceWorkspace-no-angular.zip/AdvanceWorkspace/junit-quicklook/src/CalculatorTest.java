import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testAdd() {
		Calculator c=new Calculator();
		int result=c.add(10, 20);				//module wise testing
																//white box testing
		int expected=30;
		assertEquals(30, result);        //will return a message
		
	}

	@Test
	void testSub() {
		Calculator c=new Calculator();
		int result=c.sub(20, 10);				//module wise testing
																//white box testing
		int expected=10;
		assertEquals(10, result);        //will return a message
		
	}

}
