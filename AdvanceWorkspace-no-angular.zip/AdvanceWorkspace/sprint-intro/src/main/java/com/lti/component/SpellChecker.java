package com.lti.component;

import org.springframework.stereotype.Component;

@Component("spellCheck")
public class SpellChecker {
	public void checkSpellingMistakes(String doc)
	{
		System.out.println("checking mistakes"+doc);
	}
}
