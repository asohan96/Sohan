package com.lti.component;

import org.springframework.stereotype.Component;

import com.lti.interfaces.Bank;

@Component("sbi")
public class SbiBank implements Bank {
public void SbiBankData()
{
	System.out.println("Data fetched");
}
}
