package com.lti.interfaces;

public interface Bank {
	public void SbiBankData();
}
