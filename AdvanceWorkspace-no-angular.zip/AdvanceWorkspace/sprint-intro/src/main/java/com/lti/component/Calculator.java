package com.lti.component;

public class Calculator {
	private int num1;
	private int num2;
	private int result;
	public String add(int a,int b) {
		this.num1=a;
		this.num2=b;
	this.	result=num1+num2;
	return "Add:" +result;	
	}

}
