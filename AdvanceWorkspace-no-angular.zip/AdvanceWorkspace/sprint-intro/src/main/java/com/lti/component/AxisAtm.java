package com.lti.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.lti.interfaces.Atm;
import com.lti.interfaces.Bank;

@Component("axis")
public class AxisAtm implements Atm {
	@Autowired
	private Bank sb;

	public void AxisAtmData() {
		System.out.println("From axis ATM");
		sb.SbiBankData();
	}

}
