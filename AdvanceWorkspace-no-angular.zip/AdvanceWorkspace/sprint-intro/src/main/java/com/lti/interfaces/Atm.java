package com.lti.interfaces;

public interface Atm {
	public void AxisAtmData();
}
