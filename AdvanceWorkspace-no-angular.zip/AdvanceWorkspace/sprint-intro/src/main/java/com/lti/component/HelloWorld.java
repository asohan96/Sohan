package com.lti.component;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("hello")
@Scope("prototype")
public class HelloWorld {

	public String sayHello(String name)
	{
		return "Hello : "+name;
	}
	
	public HelloWorld() {
	System.out.println("---------DEFAULT HelloWorld ()---------");
	}
}
