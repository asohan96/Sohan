package com.lti.component;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("s") // bean id
@Scope("singleton")
public class Shape {
	
	public void draw() {
		System.out.println("draw");
	}
}
