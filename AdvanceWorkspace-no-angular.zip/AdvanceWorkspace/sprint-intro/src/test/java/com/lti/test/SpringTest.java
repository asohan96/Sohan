package com.lti.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.AxisAtm;
import com.lti.component.Calculator;
import com.lti.component.HelloWorld;
import com.lti.component.Shape;
import com.lti.component.TextEditor;
import com.lti.interfaces.Atm;

public class SpringTest {

	@Test
	public void test() {
		// loading spring
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing one of the bean
		for (int i = 0; i < 10; i++) {
		HelloWorld h = (HelloWorld) ctx.getBean("hello");// bean id
		System.out.println(h.sayHello("Sohan"));
	}
		}
	@Test
	public void addTest() {
		// loading spring
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing one of the bean
		Calculator c=(Calculator)ctx.getBean("add1");
		System.out.println(c.add(10, 20));
	}
	@Test
	public void drawTest() {
		// loading spring
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing one of the bean
		
		Shape s=(Shape) ctx.getBean("s");
		s.draw();
	}
	@Test
	public void EditorAndSpellingMistakesTest() {
		// loading spring
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing one of the bean
		
		TextEditor editor=(TextEditor) ctx.getBean("textEdit");
		editor.loadDocument("doc");
	}

	@Test
	public void BankDependencyInjectTest() {
		// loading spring
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		//Accessing one of the bean
		
		Atm axis=(Atm) ctx.getBean("axis");
		axis.AxisAtmData();
	}
}
