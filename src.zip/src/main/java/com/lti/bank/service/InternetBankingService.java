package com.lti.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.bank.dao.GenericDao;
import com.lti.bank.dto.InternetBankingDTO;
import com.lti.bank.entity.InternetBanking;
import com.lti.bank.entity.Account;

@Service
public class InternetBankingService {

	@Autowired
	private GenericDao dao;

	@Transactional
	public void register(InternetBankingDTO internetBankingDTO) {
		Account acc = dao.fetchAccount(internetBankingDTO.getAccountNumber());
		InternetBanking netbank = new InternetBanking();
		netbank.setOpeningAccount(acc);
		netbank.setLoginPassword(internetBankingDTO.getLoginPassword());
	//	netbank.setConfirmLoginPassword(internetBanking.getConfirmLoginPassword());
		netbank.setTransactionPassword(internetBankingDTO.getTransactionPassword());
		//netbank.setConfirmTransactionPassword(internetDTO.getConfirmTransactionPassword());
		dao.registerForInternetBanking(netbank);
	}

}
