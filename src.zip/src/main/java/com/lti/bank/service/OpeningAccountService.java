package com.lti.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bank.dao.GenericDao;
import com.lti.bank.dto.OpeningAccountDTO;

import com.lti.bank.entity.AccountApplication;
import com.lti.bank.entity.InternetBanking;

@Service
public class OpeningAccountService {
	@Autowired
	private GenericDao openAccountApplication;

	@Transactional
	public boolean openAccountService(OpeningAccountDTO openAccountDTO) {

		double savingInitialBalance = 1000;
		if ((openAccountDTO.getInitialBalance() >= savingInitialBalance
				&& openAccountDTO.getAccountType().equals("SavingAccount"))
				|| openAccountDTO.getAccountType().equals("CurrentAccount")) {
			AccountApplication accountApplication = new AccountApplication();
			// account number auto generation..no need to set
			accountApplication.setAccountType(openAccountDTO.getAccountType());
			accountApplication.setAccountDate(new Date());
			accountApplication.setInitialBalance(openAccountDTO.getInitialBalance());

			accountApplication.setTitle(openAccountDTO.getTitle());
			accountApplication.setFirstName(openAccountDTO.getFirstName());
			accountApplication.setMiddleName(openAccountDTO.getMiddleName());
			accountApplication.setLastName(openAccountDTO.getLastName());
			accountApplication.setFatherName(openAccountDTO.getFatherName());
			accountApplication.setMobileNumber(openAccountDTO.getMobileNumber());
			accountApplication.setEmailId(openAccountDTO.getEmailId());
			accountApplication.setAadharCardNumber(openAccountDTO.getAadharCardNumber());
			try {// dd-MM-yyyy
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse(openAccountDTO.getDateOfBirth());
				accountApplication.setDateOfBirth(date);
			} catch (ParseException e) {
			}
			accountApplication.setResidentialAddressLine1(openAccountDTO.getResidentialAddressLine1());
			accountApplication.setResidentialAddressLine2(openAccountDTO.getResidentialAddressLine2());
			accountApplication.setResidentialLandmark(openAccountDTO.getResidentialLandmark());
			accountApplication.setResidentialState(openAccountDTO.getResidentialState());
			accountApplication.setResidentialCity(openAccountDTO.getResidentialCity());
			accountApplication.setResidentialPincode(openAccountDTO.getResidentialPincode());
			accountApplication.setPermanentAddressLine1(openAccountDTO.getPermanentAddressLine1());
			accountApplication.setPermanentAddressLine2(openAccountDTO.getPermanentAddressLine2());
			accountApplication.setPermanentLandmark(openAccountDTO.getPermanentLandmark());
			accountApplication.setPermanentState(openAccountDTO.getPermanentState());
			accountApplication.setPermanentCity(openAccountDTO.getPermanentCity());
			accountApplication.setPermanentPincode(openAccountDTO.getPermanentPincode());
			accountApplication.setAtmCard(openAccountDTO.getAtmCard());
			
			//auto generate ifsc code
			accountApplication.setOccupationType(openAccountDTO.getOccupationType());
			accountApplication.setGrossAnnualIncome(openAccountDTO.getGrossAnnualIncome());
			// if(openAccountDTO.getnetbanking.equals("checked"))
			
			openAccountApplication.accountApproval(accountApplication);
			AccountApplication a=accountApplication;
			
			InternetBanking netbanking = new InternetBanking();
			netbanking.setOpeningAccount(accountApplication);
			netbanking.setUserId(a.getAccountNumber());
			netbanking.setLoginPassword(openAccountDTO.getLoginPassword());
			netbanking.setTransactionPassword(openAccountDTO.getTransactionPassword());
			openAccountApplication.registerForInternetBanking(netbanking);
			return true;
		} else
			return false;
	}
}
