package com.lti.bank.entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="TBL_InternetBanking2")
public class InternetBanking {
	
	@Id
	@GeneratedValue
	private long userId;
	@OneToOne
	@JoinColumn(name="accountNumber")
	private AccountApplication openingAccount;
	
	private String loginPassword;
	private String transactionPassword;
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public AccountApplication getOpeningAccount() {
		return openingAccount;
	}
	public void setOpeningAccount(AccountApplication openingAccount) {
		this.openingAccount = openingAccount;
	}

}