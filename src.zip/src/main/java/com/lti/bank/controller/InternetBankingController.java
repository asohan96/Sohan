package com.lti.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.bank.dto.InternetBankingDTO;
import com.lti.bank.entity.InternetBanking;
import com.lti.bank.service.InternetBankingService;

@Controller
public class InternetBankingController {
	@Autowired
	private InternetBankingService internetService;
		
		@RequestMapping(path = "/net-banking", method = RequestMethod.POST)
		public String register(InternetBankingDTO internetBankingDTO) {
		
			internetService.register(internetBankingDTO);
			return "redirect:/register-for-internet-banking.jsp";
	}
	
}
