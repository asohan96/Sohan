package com.lti.bank.controller;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.bank.dto.OpeningAccountDTO;
import com.lti.bank.service.OpeningAccountService;

@Controller
public class OpeningAccountController {
	boolean successfullOpen;
	@Autowired
	private OpeningAccountService openingAccountService;
	
	@RequestMapping(path="/open-account", method=RequestMethod.POST)
	public String openAccount(OpeningAccountDTO openAccountDTO,Map<String, Object> model) {		
		successfullOpen=openingAccountService.openAccountService(openAccountDTO);
		if(successfullOpen==true) {
			model.put("openAccountDetails", openAccountDTO);
		return "/account-application-successfull.jsp";}
		else
			return "/account-application-unsuccessfull.jsp";
			
	}

}
