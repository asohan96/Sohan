package com.lti.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.lti.bank.entity.AccountApplication;
import com.lti.bank.entity.InternetBanking;

@Repository
public class GenericDao {
	@PersistenceContext
	private EntityManager entityManager;

	public void accountApproval(AccountApplication accountApplication)
	{
		entityManager.persist(accountApplication);
	}
	
	public void addAccount(AccountApplication openAccount) {
		entityManager.persist(openAccount);

	}
	
	public AccountApplication fetchAccount(long accountNumber) {
		return entityManager.find(AccountApplication.class, accountNumber);

	}
	
	public void registerForInternetBanking(InternetBanking netBank) {
		
		entityManager.merge(netBank);
	}
	
	
}
