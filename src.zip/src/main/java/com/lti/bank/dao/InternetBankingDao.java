/*package com.lti.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.bank.Entity.InternetBanking;
@Repository
public class InternetBankingDao {
@PersistenceContext
private EntityManager entityManager;
@Transactional
	public void add(InternetBanking netBank) { // addvalues into register tables
	
	entityManager.persist(netBank);
}
}*/
