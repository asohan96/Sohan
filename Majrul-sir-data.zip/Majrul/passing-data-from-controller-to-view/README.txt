Please refer to comments in RegisterController.java

