package com.lti.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.dto.RegisterDTO;
import com.lti.entity.Register;
import com.lti.service.RegisterService;

@Controller
public class RegisterController {

	@Autowired
	private RegisterService registerService;
	
	@RequestMapping(path="/register", method=RequestMethod.POST)
	public String register(RegisterDTO registerDTO, 	Map<String, Object> model) {
		
		//TODO : rename the file since two users can upload file of same name
		File targetDir = new File("d:/uploads/" + registerDTO.getProfilePic().getOriginalFilename()); 
		try {
			registerDTO.getProfilePic().transferTo(targetDir);
		}
		catch (IOException e) {
			e.printStackTrace(); //if copy fails, throw an exception instead
		}
		
		int id = registerService.register(registerDTO);
		registerDTO.setGeneratedId(id);
		
		model.put("registrationDetails", registerDTO);
		return "/confirmation.jsp";
	}
	
	@RequestMapping(path="/fetch", method=RequestMethod.GET)
	public String list(@RequestParam int id, Map<String, Object> model, HttpServletRequest request) {
		Register register = registerService.getRegisteredUser(id);
		
		String appRoot = request.getServletContext().getRealPath("/");
		File srcFile = new File("d:/uploads/" + register.getProfilePicFileName());
		File destFile = new File(appRoot + "/uploads/"+register.getProfilePicFileName());
		System.out.println(appRoot);
		System.out.println(srcFile.getName());
		System.out.println(destFile.getName());
		try {
			FileUtils.copyFile(srcFile, destFile);
		}
		catch (IOException e) {
			e.printStackTrace(); //if copy fails, throw an exception instead
		}
		
		model.put("user", register);
		return "/displayUser.jsp";
	}
	
	@RequestMapping(path="/list", method=RequestMethod.GET)
	public String list(Map<String, Object> model) {
		List<Register> list = registerService.getRegisteredUsers();
		model.put("listOfUsers", list);
		return "/displayUsers.jsp";
	}

}
