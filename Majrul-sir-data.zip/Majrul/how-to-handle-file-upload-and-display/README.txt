to enable support for file upload in spring, add the following dependency in pom.xml:

	<!-- https://mvnrepository.com/artifact/commons-fileupload/commons-fileupload -->
		<dependency>
		    <groupId>commons-fileupload</groupId>
		    <artifactId>commons-fileupload</artifactId>
		    <version>1.3.3</version>
		</dependency>


Then in the spring-config.xml add the following bean entry:

	<!-- support for Commons File Upload -->
	<bean id="multipartResolver"
	        class="org.springframework.web.multipart.commons.CommonsMultipartResolver">
	
	    <!-- one of the properties available; the maximum file size in bytes -->
	    <property name="maxUploadSize" value="10000000"/>
	</bean>


Refer to register.jsp, RegisterController, RegisterDTO to understand how the file upload process works



