package st_sohan;

public class Chocolate {
	int rs;
	int wrappers;

}
