package st_sohan;

import java.util.Scanner;

public class Curr {
private String src;
private String dst;
private String [] curr= {"INR","USD","DRM","JPY","YEN"};
private int amt;
public Curr(String src, String dst, int amt) {
	int flag=0;
	this.src = src;
	this.dst = dst;
	this.amt = amt;
	for(int i=0;i<curr.length;i++)
	{
		if(curr[i].equalsIgnoreCase(src) && curr[i].equalsIgnoreCase(dst))
		{
			flag=1;
			if(curr[i]==curr[0]||curr[i]==curr[1]||curr[i]==curr[2]||curr[i]==curr[3]||curr[i]==curr[4])
				
			System.out.println("source : "+curr[i]);
			System.out.println("DEST : "+curr[i]);
			break;
			
		}
	}
}
public static void main(String[] args) {

	Curr c=new Curr("INR", "DRM", 100);
}

}
