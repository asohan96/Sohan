
public class DataTypeDemo {

	public static void main(String[] args) {
		int i=123;
		long l=99998765432L;   //to convert int into long put L end of the no
		double d=0.456324;
		float f=3.14F;                //to convert d to f put F end of float val
		boolean b=true;
		char c='\u0063';           //std code for z
		
		System.out.println("INT" +i);
		System.out.println("LONG" +l);
		System.out.println("DOUBLE" +d);
		System.out.println("FLOAT" +f);
		System.out.println("BOOLEAN" +!b);   //!b for false
		System.out.println("CHAR" +c);
				

	}

}
