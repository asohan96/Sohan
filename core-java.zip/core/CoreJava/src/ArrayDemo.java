
public class ArrayDemo {

	public static void main(String[] args) {
//		int[ ] ar= {10,20,30,40,50};
		int[][] jaggu= {{1,2},{3,4,5},{6,7,8,9}};
		for (int k = 0; k < jaggu.length; k++)
		{
			
			for (int m = 0; m < jaggu[k].length; m++)
			{
				System.out.print(jaggu[k][m]+"\t");
				
				
			}
		System.out.println();
		}
	/*	for(int i=0;i<ar.length;i++)
		{
			System.out.println(ar[i]);
		}
		
for (int j: ar) {
System.out.println(j);	
}*/
	}

}
