
public class Prime {

	public static void main(String[] args)
	{
		 
		int num=100;
		int i;
		
		for (i = 1; i <= 100; i++)         
	       { 		  	  
	          int counter=0; 	  
	          for(num =i; num>=1; num--)
		
	          {
	             if(i%num==0)
		     {
	 		counter = counter + 1;
		     }
	
	          }
	       }
	}
}