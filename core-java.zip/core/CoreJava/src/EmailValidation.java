import java.util.Scanner;

public class EmailValidation {
	/*
	 * Validation Rules there shld be only 1 -1 occurrences of '@' and '.' min 4
	 * letters before @ min 3 letters between @ and . min 2 letters after.
	 */
	public static void main(String[] args) {
		// String email="zubair@mail.com";
		Scanner s = new Scanner(System.in);
		String email = s.nextLine();
		System.out.println("VALIDATION");
		 int m=(email.indexOf('@'));
		// int n=(email.indexOf('.'));
		 int n=(email.lastIndexOf('.'));

		if ((m == email.indexOf('@')) && (m < n) && (m > 3) && ((n - m) > 4) && ((email.length() - (n + 1)) > 2)) {
			System.out.println("valid");

		} else
			System.out.println("in-valid");
	}
}
