
public class CmdLineDemo {

	public static void main(String[] args) {
		int sum=0;
		for (String arg : args) {
			sum+=Integer.parseInt(arg);

			
		}
		System.out.println("addition"+sum);
//auto-boxing:
		int x=10;
		Integer xobj=x;//boxing
		int y=xobj+ 5;//unboxing
	}

}
