
package test;

public class ClassA {
 public static void doStuff() {
     System.out.println("doStuff");
 }
}



