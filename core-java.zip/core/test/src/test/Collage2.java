package test;

public class Collage2 {
public static void main(String[] args) {
	Phone p=new Tablet();
	System.out.println(p.cell+" : "+p. );
}
}
