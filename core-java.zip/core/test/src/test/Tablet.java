package test;

public class Tablet extends Phone{
	boolean playmovie=false;
	

}
