package test;

public class Phone {
String cell="samsung";

}
