package c;

public class Fi extends Fin{
public static void main(String[] args) {
	System.out.println(a);
}
}
