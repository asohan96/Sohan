package c;

public class Asd extends Zaq{

	@Override
	public void Terr() {
		System.out.println("in terr");
		
	}
	public static void main(String[] args) {
		Asd a=new Asd();
		a.base();
		a.Terr();
	}
	

}
