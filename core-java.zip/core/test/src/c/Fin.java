package c;

public class Fin {
final static int a =100;


}
