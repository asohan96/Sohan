package c;
public abstract class Zaq extends Zxc
{

	@Override
	public void base() {
		System.out.println("in class base");
		
	}

	
}