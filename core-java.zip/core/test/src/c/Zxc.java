package c;

public abstract  class Zxc {
	
	
public abstract void base();
public abstract void Terr();


}

