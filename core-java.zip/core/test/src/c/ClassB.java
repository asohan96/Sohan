package c;

import test.ClassA;

public class ClassB {
	 public static void main(String args[]) {
	ClassA.doStuff();
	 }
	}
