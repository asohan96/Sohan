import java.util.Date;
import java.util.Calendar;
import java.util.TimeZone;
import static java.util.Calendar.*;

public class TimeZoneDemo {

	public static void main(String[] args) {

		TimeZone zone = TimeZone.getTimeZone("EST");

		Calendar cal = getInstance(zone);
		System.out.println(cal.get(HOUR_OF_DAY));
		System.out.println(cal.get(MINUTE));
		Date now = new Date();
		System.out.println(now);
		/*
		 * String[] zones=TimeZone.getAvailableIDs(); for (String zone : zones)
		 * System.out.println(zone); System.out.println(zones.length);
		 */
	}
}
