import java.util.Locale;
import java.util.ResourceBundle;

public class Localization {
	public static void main(String[] args) {
		Locale en = new Locale("en"); // To create custom locale for hindi
		ResourceBundle bundle = ResourceBundle.getBundle("greeting", en);
		
		// ResourceBundle bundle=ResourceBundle.getBundle("greeting",Locale.FRANCE);
		// inbuilt Locale
		System.out.println(bundle.getString("message"));
		System.out.println(bundle.getString("greeting"));

	}
}
