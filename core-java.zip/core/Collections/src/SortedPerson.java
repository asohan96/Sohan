import java.util.TreeSet;

public class SortedPerson {
public static void main(String[] args) {
	PersonComparator pc=new PersonComparator();				//TO COMPARE OBJECT USING COMPARE() OF COMPARATOR
	TreeSet<Person> persons=new TreeSet<>(pc);
	persons.add(new Person("Polo",21));
	persons.add(new Person("Lilli",19));
	persons.add(new Person("Milli",20));
	
	for (Person person : persons) {
		System.out.println(person);
	}
}
}
