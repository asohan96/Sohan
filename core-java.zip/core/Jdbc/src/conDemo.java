import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class conDemo {
	public static void main(String[] args) {
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String driver = "oracle.jdbc.OracleDriver";
		String sql = "insert into category values(12,'James')";
		try {
			Class.forName(driver);
			System.out.println("Driver Loaded");
			conn = DriverManager.getConnection(url, "stuser", "sohan123");
			System.out.println("Connection Established");
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);

			System.out.println("record insserted");
		} catch (Exception e) {
			System.out.println("Record insertion failed due to");
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
}