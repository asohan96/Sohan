import java	.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class TransactionDemo {
public static void main(String[] args) {
	String sql1="insert into person values('Mili',20,'Mumbai')";
	String sql2="update person set age=23 where name='Polo'";
	String sql3="delete from person where name='arbaz'";
	Connection conn=null;
	try {
		conn=JdbcFactory.getConnection();
		Statement stmt=conn.createStatement();
		stmt.addBatch(sql1);
		stmt.addBatch(sql2);
		stmt.addBatch(sql3);
		//setting auto commit off
		conn.setAutoCommit(false);
		//Performing DML
		stmt.executeBatch();
		//everything goes fine -commit changes
		conn.commit();
		System.out.println("Transaction completed successfully");
	} catch (SQLException e) {
	System.out.println("Transaction failed due to");
		e.printStackTrace();
	try {
		conn.rollback();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	finally {
		if(conn!=null)
			try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}
	}
	
	
}
}
