import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrecompileDemo {
public static void main(String[] args) {
	String sql="insert into person values(? ,?, ?)";		//? is known as palce holder position starts from 1
	Connection conn=null;
	try {
		conn=JdbcFactory.getConnection();
		PreparedStatement stmt=conn.prepareStatement(sql);
		//Replacing place holders with data
		/*for (int i = 0; i <5; i++) {
			stmt.setString(1, args[i]);
			stmt.setInt(2, Integer.parseInt(args[i+1]));
			stmt.setString(3,args[i+2]);
			stmt.executeUpdate();
		}*/
		
		stmt.setString(1, args[0]);
		stmt.setInt(2, Integer.parseInt(args[1]));
		stmt.setString(3,args[2]);
		stmt.executeUpdate();
		System.out.println("Recordings are inserted");
		ResultSet rs=stmt.executeQuery("select name,age,city from person");
		while (rs.next()) {
			System.out.println();
							//System.out.printf("%-20s/t%3d/t%-20s", rs.getString(1), rs.getInt("age"), rs.getString("city"));
					System.out.println(rs.getString(1)+"\t"+rs.getString("age")+"\t"+ rs.getString("city"));
						}
	}  catch (SQLException e) {
		e.printStackTrace();
	}
	catch (NumberFormatException e) {
		e.printStackTrace();
	}finally {
		if (conn != null)
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
}

