import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class StatementDemo {
	public static void main(String[] args) {
		String sql = "insert into person values('Polo',21,'Pune')";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			// getting connection
			// creating statements to fire hard codded fixed querry
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);// performing DML oprations

			System.out.println("record insserted");
		} catch (SQLException e) {
			System.out.println("Record insertion failed due to");
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
