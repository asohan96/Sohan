import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class QueryAnalyzer {
public static void main(String[] args) {
	String sql = "update person set age=80 where name='Sohan'";
	Connection conn = null;

	try {
		conn = JdbcFactory.getConnection();
		//ResultSet rs = conn.createStatement().executeQuery(sql);
Statement stmt=conn.createStatement(
		ResultSet.TYPE_SCROLL_INSENSITIVE,
		ResultSet.CONCUR_UPDATABLE);
//ResultSet rs=stmt.executeQuery(sql);
		ResultSet rs=stmt.executeQuery(sql);
		//ResultSet r=stmt.execute("select * from person");
		ResultSetMetaData meta=rs.getMetaData();
		for (int i = 1;  i<=meta.getColumnCount(); i++) {
			System.out.print(meta.getColumnLabel(i)+"\t");
			
		}
		while (rs.next()) {
System.out.println();
			//System.out.printf("%-20s/t%3d/t%-20s", rs.getString(1), rs.getInt("age"), rs.getString("city"));
	System.out.println(rs.getString(1)+"\t"+rs.getString("age")+"\t"+ rs.getString("city"));
		}} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} finally {
		if (conn != null)
			try {
				conn.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
	}
}

}

