import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDemo {
	public static void main(String[] args) {
		//String url = "jdbc:oracle:thin:@localhost:1521:xe";
		Connection conn = null;
		try {
//			Class.forName("oracle.jdbc.OracleDriver");
//			conn = DriverManager.getConnection(url, "stuser", "sohan123");
			conn = JdbcFactory.getConnection();
			System.out.println("CONNECTED SUCCESFULLY...");
	
			DatabaseMetaData meta=conn.getMetaData();
			System.out.println(meta.getDatabaseProductName());
			System.out.println(meta.getDatabaseProductVersion());
			System.out.println(meta.getDriverName());
			System.out.println(meta.getDriverVersion());
			
//			
//		} catch (ClassNotFoundException e) {
//
//			e.printStackTrace();
	}
			catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

	}
}
