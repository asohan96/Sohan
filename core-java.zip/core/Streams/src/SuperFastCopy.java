import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import javax.imageio.stream.FileCacheImageInputStream;

public class SuperFastCopy {
	public static void main(String[] args) {
		FileInputStream inFile=null;
		FileOutputStream outFile=null;
		FileChannel inChannel=null;
		FileChannel outChannel=null;
		try {
			inFile=new FileInputStream("D:/stuser/tanuja/vs.exe");
			outFile=new FileOutputStream("D:/stuser/tanuja/newvs.exe");
			inChannel=inFile.getChannel();
			outChannel=outFile.getChannel();
			ByteBuffer buffer=ByteBuffer.allocateDirect(1024*16);		//SUPERDUPERFAST- allocation of memoruon os-level memory
			//ByteBuffer buffer=ByteBuffer.allocate(1024*16);		//allocation of memory on jvm
			
			//outBuffer=new BufferedOutputStream(outFile,1024*16);
			//int ch=0;
			long ms1=System.currentTimeMillis();
			while(true) {
				//ch=inBuffer.read();
				int count=inChannel.read(buffer);
				
				if(count==-1)
				break;
				buffer.flip();
				outChannel.write(buffer);
				buffer.clear();
				//outBuffer.write(ch);
			}
			long ms2=System.currentTimeMillis();
			System.out.println("FIL:E COPIED SUCCESFULLY IN : "+(ms2-ms1)+" ms");
			
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		finally {
			try{
				inFile.close();
				outFile.close();
				
			}catch(Exception e)
			{
				
			}
		}
	}
}
