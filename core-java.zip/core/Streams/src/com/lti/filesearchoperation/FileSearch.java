package com.lti.filesearchoperation;

import java.io.File;

public class FileSearch {
	public void findFile(String name,File file)
	{
		File [] list=file.listFiles();
		if(list!=null)
			for(File fil:list)
			{
				if(fil.isDirectory())
				{
					findFile(name, fil);
				}
				else if(name.equalsIgnoreCase(fil.getName()))
					System.out.println("THE FILE IS PRESENT IN : " + fil.getParentFile());

			}
		
	}
	
public static void main(String[] args) {
	FileSearch fs=new FileSearch();
	String directory="D:/";
	fs.findFile("tanu.txt", new File(directory));
	
}
}
