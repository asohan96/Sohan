import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {
	public static void main(String[] args) {
		String path = "D:/stuser/tanuja/tanu.txt";
		String line = null;
		FileReader reader = null;
		BufferedReader buffer = null;
		try {
			reader = new FileReader(path);
			buffer = new BufferedReader(reader);
			while (true) {
				line = buffer.readLine();
				if (line == null)  
					break;
				System.out.println(line);
			}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} finally {
			try {
				buffer.close();
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
