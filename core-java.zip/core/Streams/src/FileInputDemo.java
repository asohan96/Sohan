import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputDemo {

	public static void main(String[] args) {

		String path = "D:/stuser/tanuja/tanu.txt";
		int c = 0;
		FileInputStream istream = null;
		try {
			istream = new FileInputStream(path);
			byte[] bar=new byte[istream.available()];
			istream.read(bar);													//FIRST APPRAOCH
			System.out.println(new String(bar));
/*	while (true) {
			c = istream.read();
			if (c == -1)																			//SECOND APPRAOCH
					break;												//TWO DIFFERENT APPRAOCHES TO READ DATA OF A FILE
			System.out.print((char) c);
*/			//}
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		catch (IOException e) {

			e.printStackTrace();
		} finally {
			if (istream != null)
				try {
					istream.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
		}
	}
}
