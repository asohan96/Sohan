
public class Person {
	private String name;
	private int age;
//default constructor
	public Person() {
		this("ANONYMOUS",-1);	// constructor chaining calls another constructor on the same object with the matching signature 
		
	}
// parameterized constructor
	public Person(String name, int age) {
												
		this.name = name;							
		this.age = age;
	}

	/*
	 * public void init(String pname , int page) { name=pname; age=page; }
	 */

	public void print() {
		System.out.println("NAME : " + name + "\tAGE : " + age);
	}

	public static void main(String[] args) {
		Person p1 = new Person("Polo", 12);
		// p1.init();
		p1.print();

		Person p2 = new Person();
		p2.print();
	}
	@Override
	public String toString() {
		return "Person name=" + name + "\t age=" + age ;
	}
	@Override
	public void finalize() throws Throwable {
		System.out.println("PERSON IS NO MORE");
	}
	
	
	//@Override
	/*public boolean equals(Object obj) {
		if(obj instanceof Person)
		
			return true;
		else return false;		
		
		//return super.equals(obj);
	}*/
	
	

}
