
public interface Exchange extends Broker{
void setQuote();
}
