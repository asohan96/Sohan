
public class Product {
protected String pname;
protected int price,stock;
public Product() {
	pname="ABC";
	price=100;
	stock=10;
	
	
}
public Product(String pname, int price, int stock) {
	
	this.pname = pname;
	this.price = price;
	this.stock = stock;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}



}
