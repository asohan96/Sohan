
public class ShoppingCart {
	
	
	public static void addProduct(Product p,int qnty)
	{
		if(p!=null)
		{
			/*pname=p.setPname();
			price=p.setPrice(price);
			*/
		}
	}
	
	/*public static void summary()
	{
		System.out.println("PRODUCT ADDED : "+p.getPname());
		System.out.println("PRICE : "+p.getPrice());
		System.out.println(" : "+);
	}
	*/

}
