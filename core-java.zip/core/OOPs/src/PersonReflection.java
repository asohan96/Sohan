import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PersonReflection {
	public static void main(String[] args) {
		Person p = new Person("Polo", 21);
		Class pc = p.getClass();
		System.out.println(pc.getName());//Class called class
		
		
		Constructor[] constructors = pc.getConstructors();
		System.out.println("--List of constructor");// get constructor from the class
		for (Constructor constructor : constructors)
			System.out.println(constructor);
		
		
		Method[] methods = pc.getMethods();
		for (Method method : methods) //get methods from the class
			System.out.println(method);
		
		
		Method[] decMethods=pc.getDeclaredMethods();
		System.out.println("--List of declared methods");
		for (Method method : decMethods) //get declared methods from the class
		System.out.println(method);
		
		Field[] fields=pc.getDeclaredFields();//get declared data (fields)members
		System.out.println("List of Fields");
		for(Field field:fields)
			System.out.println(field); 
		
	}
}
