
public interface Broker extends Holder{
void getQuote();
}
