
public class TestPerson {
public static void main(String[] args) {
/*	Person p1=new Person("POLO",21);
	Person p2=new Person("POLoO",21);
	System.out.println(p1.hashCode());//hashcode
	System.out.println(p2.hashCode());
	System.out.println(p1);
	System.out.println(p2);
	System.out.println(p1.equals(p2));
	
*/	
	
	
	Person p=null;
	for(int c=1;c<=5;c++)
	
	p=new Person();
	
	System.gc();
	
	
}
}
