
public class Printer {
public void print()
{
	
}
}
