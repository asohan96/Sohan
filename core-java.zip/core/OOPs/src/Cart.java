
public interface Cart {

}
