
public interface Holder {
	void viewQuote();

}
