
public class Car {

	private String model;
	private String[] features;
	public Car(String model,String... features)
	{
		this.model=model;
		this.features=features;
		
	}
	public void specs()
	{
		System.out.println("The Features of: "  +model);
		for(String feature:features)
			System.out.println(feature);
		
	}
	public static void main(String[] args) {
	//	String[] falto= {"Keyless Entry","Power Steering","Power Window"};
		Car alto=new Car("SUZUKI ALTO","Keyless Entry","Power Steering","Power Window");
		//String[] fbal= {"Keyless","ABS","Pano Roof","Airbags","Cruise Control"};
		Car baleno=new Car("Suzuki Baleno","Keyless","ABS","Pano Roof","Airbags","Cruise Control");
	
			alto.specs();
			baleno.specs();
	}
	}

