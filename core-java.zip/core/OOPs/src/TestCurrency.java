import com.lti.cc.AED;
/*import com.lti.cc.CurrencyConverter;
import com.lti.cc.INR;
import com.lti.cc.USD;
*/
import static com.lti.cc.Currency.*;


public class TestCurrency {
	public static void main(String[] args) {
		
		//CurrencyConverter cc = new CurrencyConverter();
		convert(INR,USD,100);
		convert(USD,INR,790);
		convert(AED,INR,900);
		
	}
}
