public class Member {
	public String name;
	public String book;
	
	public Member() {

	}
	
	public Member(String mbr) {
		this.name = mbr;
	}
	
	
	public String getName() {
		return name;
	}
	

	public void setBook(String book) {
		this.book = book;
	}

	public void status() {
		if(book == null) {
			System.out.println("The member "+name+" has not issued any book.");
		}
		else System.out.println(name +" has issued the book "+book +".");
	}
	
}



