
public abstract class Employee {

	
	private int empNo;
	private String empName;
	private double salary;
	private static int autogen;
	static //static initializer block 
	{
		System.out.println("class employee loaded...");
		autogen=1001;
	}
	
	
	public Employee(String empName, double salary) {
	//	super();
		this.empNo = autogen++;
		this.empName = empName;
		this.salary = salary;
	}



	public double getSalary() {
		return salary;
	}



	public Employee() {
		this("Tanuja",5000);
	}
	public void payslip()
	{
		System.out.println("EmpNO : "+empNo);
		System.out.println("EmpName : "+empName);
		System.out.println("Salary : "+salary);
	}



}
