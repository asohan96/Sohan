public class EventDemo implements Event {

	@Override
	public void doSomething() {
		System.out.println("FIRST IMPLMENTATION");

	}

	static class EventImpl implements Event {

		@Override
		public void doSomething() {
			System.out.println("2ND IMPLEMENTATION");

		}
	}

	public void SecondEvent() {
		Event e = new EventImpl();
		e.doSomething();
	}

	public void thirdEvent() {
		class InnerEvent implements Event {

			@Override
			public void doSomething() {
				System.out.println("Third Implementation");

			}

		}
		Event e = new InnerEvent();
		e.doSomething();
	}

public void OneMoreEvent()
{
	Event e=new Event() {
		
		@Override
		public void doSomething() {
			System.out.println("Fourth Implementation");			
		}
	};
	
	e.doSomething();
}

public void OneLastEvent()
{
	Event e=()-> System.out.println("FIFTH EVENT");
	e.doSomething();
}
	public static void main(String[] args) {
		EventDemo demo = new EventDemo();
		demo.doSomething();
		demo.SecondEvent();
		demo.thirdEvent();
		demo.OneMoreEvent();
		demo.OneLastEvent();
	}

}
