
public class TestAccount {
	public static void main(String[] args) {
	/*Bank c1=AccountFactory.openAccount("POLO", "Savings");
	System.out.println("*-----------*------CURRENT TRANSACTIONS----*-------------");
         c1.withdraw(3000);
         c1.withdraw(5000);
         c1.summary();
         System.out.println("*-----------*----------*-------------");
         
         c1.deposit(2000);
         c1.deposit(4000);
         c1.summary();
         */
         System.out.println("*-----------*------SAVING TRANSACTION----*-------------");
         Bank s1=new SavingAccount("SOHAN");
         s1.withdraw(1500);
         /*s1.deposit(12000);
         s1.withdraw(5600);
         s1.deposit(3200);*/
         s1.statement();
	}
}
