
public class Stock implements Exchange {
	public String Quote;

	public void viewQuote() {
		System.out.println("VIEW-QUOTE");
	}

	public void getQuote() {
		System.out.println("GET-QUOTE");
	}

	public void setQuote() {
		System.out.println("SET-QUOTE");
	}

}