
public class TestSam {
public void testHello()
{
	Hello h=(name)-> "Hello"+name;
	System.out.println(h.sayHello("Zubair"));
	System.out.println(h.sayBye("Zubair"));
}
public static void main(String[] args) {
	TestSam sam=new TestSam();
	sam.testHello();
	System.out.println(Hello.max(10, 20));
	
}
}
