
public class StringDemo {
	public static void main(String[] args) {
		String s="abcd";
		String s1="xyz";
		String a=s.concat(s1);
		System.out.println(a);
		System.out.println(s+"abcd");
		
	}
}
