
public class TestStock {
	public static void main(String[] args) {
		//Stock lti=new Stock();//singleton implementation
		Holder h=StockObject.getStock();
		h.viewQuote();
		System.out.println("----------------------");
		Broker b=StockObject.getStock();;
		//b.viewQuote();
		b.getQuote();
		System.out.println("----------------------");
		Exchange e=StockObject.getStock();
		//e.viewQuote();
		//e.getQuote();
		e.setQuote();
		System.out.println("END");
		
	}
}
