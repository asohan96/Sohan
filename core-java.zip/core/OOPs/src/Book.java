public class Book {
	private String title;
	private String mbr;
	
	public Book (String title) {
		this.title = title;
	}
	
	public void status() {
		if(mbr == null) {
			System.out.println("The book " + title + " is not issued to any member");
		}
		//else System.out.println("The book " + title + " is issued to"+ mbr.getName());
	}
	
	
	public String getTitle() {
		return title;
	}
/*
	public void issueBook( Member mbr) {
		this.mbr=mbr;
		mbr.setBook(this);
		
	}
	
	public void returnBook() {
	this.mbr=null;
	mbr.setBook(null);
	}*/
	
}