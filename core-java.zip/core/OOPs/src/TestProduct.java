
public class TestProduct {
public static void main(String[] args) {
	Product p=new Product("IPHONE",4500,3);
	/*p.addProduct(p,3);
	p.show();
	*/
}
}

