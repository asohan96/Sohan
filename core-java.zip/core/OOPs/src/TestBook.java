
public class TestBook {

	public static void main(String[] args) {
		Book B1 = new Book("JAVA 3");
		Book B2 = new Book("JAVA  8");
		
		Member M1 = new Member("JOHN");
		Member M2 = new Member("KARTIK");
		
		//B1.issueBook( M1);
		//B2.status();
		//B1.returnBook("Harry Potter");
		//B1.status();
		//B2.returnBook("Harry Potter 2");
		B2.status();
		//B2.returnBook();
		//B1.issueBook("Harry Potter", M2.name);
		//B1.status();
		//B1.returnBook("Harry Potter");
		//B1.status();
		
		M1.status();
		

	}

}
