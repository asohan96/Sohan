

public class CurrencyConverter  {
 
		double marval[][] = { { 1, 0.014, 0.052},
							  { 71.18, 1, 3.67 },
							  { 19.38, 0.27, 1 } };

		public void convert(int src, int tar, double amt) {
			System.out.println("CONVERSION:" + (amt * marval[src][tar]));
		}

	}


