	public abstract class AccountDetails implements Bank {
	// variables declared
	private int accNo;
	private String holder;
	protected double balance;

	
	// auto-generate accno
	private static int autogen = INIT_ACCNT_NO;
	protected Transaction[] txns;							 //transaction class array -for savings acc
	protected int idx;                   							//index of txns -total no of transaction
	//constructor
	public AccountDetails() {

	}
//para-constructor
	public AccountDetails(String holder, double balance) {

		this.accNo = autogen++; // autogen
		this.holder = holder;
		this.balance = balance;
	}
//methods
	public void summary() {
		System.out.println("AcNo : " + accNo);
		System.out.println("Holder : " + holder);
		System.out.println("Balance : " + balance);
	}

	public void deposit(double amount) {
		balance = balance + amount;
		txns[idx++]=new Transaction("CR", amount, balance);
	}

	@Override
	public void statement() {
		System.out.println("Transaction of account"+accNo);
		for(int i=0;i<idx;i++)
			txns[i].print();
	}
	public abstract void withdraw(double amount);
}
/*
 * if (amount > balance) System.out.println("Insufficient Funds"); else balance
 * = balance - amount; }
 */
