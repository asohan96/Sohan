
public final class AccountFactory {
	
	private AccountFactory() {
		
	}
public static Bank openAccount(String holder,String type)
{
	Bank acnt=null;
	if(type.equalsIgnoreCase("Savings :"))
		acnt=new SavingAccount(holder);
	else
		acnt=new CurrentAccount(holder);
	return acnt;
}
}
