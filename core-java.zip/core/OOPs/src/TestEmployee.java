
public class TestEmployee {

	public static void main(String[] args) {
		
		Executive exec=new Executive("POLO",5000,2000);
		
		
	
		
		Manager man=new Manager("MILI",2350,5400);
		showSalary(exec);
		showSalary(man);
	}
	private static void showSalary(Employee e)
	{
		if(e  instanceof Manager)
		{
			System.out.println("Manager Salary : "+e.getSalary());
			
		}
		else
		{
			System.out.println("Executive Salary : "+e.getSalary());
		}
	}
	
	//Method overloading
/*private static void  showSalary(Executive exec)
{
	System.out.println("Executive salary : "+exec.getSalary());
	}
private static void  showSalary(Manager man)
{
	System.out.println("Manager salary  : "+man.getSalary());
	}
*/
	}
