
public class GenericDemo<Z> {
private Z data;

public GenericDemo(Z data) {
	super();
	this.data = data;
}

public Z getData() {
	return data;
}

public void setData(Z data) {
	this.data = data;
}
public static void main(String[] args) {
	GenericDemo<String> d1=new GenericDemo<String>("Hello");
	//d1.setData(123);
	System.out.println(d1.getData());
	GenericDemo<Integer> d2=new GenericDemo<Integer>(23);
	System.out.println(d2.getData());
	
	GenericDemo d3=new GenericDemo(123);
	d3.setData("HEY");
	System.out.println(d3.getData());
	
}
}
