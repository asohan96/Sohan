
/*public class Paper {
String text;
public void setText()
}
*/