package com.lti.polymorph;

public interface Polymorphism {
	
public String pol();

}
