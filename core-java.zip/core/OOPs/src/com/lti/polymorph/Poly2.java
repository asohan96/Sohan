package com.lti.polymorph;

public class Poly2 implements Polymorphism{

	@Override
	public String pol() {
		System.out.println("2100");
		return "100";
	}

}
