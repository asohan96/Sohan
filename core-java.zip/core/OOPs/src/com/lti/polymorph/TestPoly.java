package com.lti.polymorph;

public class TestPoly {

	public static void main(String[] args) {
		Polymorphism p=new ProgramPoly();
		p.pol();
		
		System.out.println("-----------");
		p=new Poly2();
		System.out.println(p.pol());
		

	}

}
