package com.lti.polymorph;

public class ProgramPoly implements Polymorphism{

	@Override
	public String pol() {
		System.out.println("2");
		return "2";
	}

}
