package com.lti.movies;

public class Thaakre implements TicketDetails{

	@Override
	public double price() {
		
		return 200;
	}
	

}
