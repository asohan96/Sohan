package com.lti.movies;

public interface TicketDetails {

	public double price();


}
