package com.lti.movies;

public class TestMovie {
	public static void main(String[] args) {
		
	
//	Simba simba = new Simba();
	
MovieBooking b=new MovieBooking(new Simba(), 2, 0);
b.Booked();
}
}