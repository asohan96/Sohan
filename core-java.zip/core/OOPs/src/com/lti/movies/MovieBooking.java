package com.lti.movies;

public class MovieBooking {
	
	protected TicketDetails movie;
	protected int noSeats;
	protected int time;
	protected int total;
	public MovieBooking(TicketDetails movie, int noSeats, int time) {
		this.movie = movie;
		this.noSeats = noSeats;
		this.time = time;
		
	}
	
	public void Booked()
	{
		total += movie.price()*noSeats;
		System.out.println(total);
	}

	


}












/*{
super();
this.movie = movie;
this.noSeats = noSeats;
this.time = time;

}*/