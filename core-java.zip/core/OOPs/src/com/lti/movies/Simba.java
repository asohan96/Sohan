package com.lti.movies;

public class Simba implements TicketDetails {

	@Override
	public double price() {
		
		return 150;
	}

}
