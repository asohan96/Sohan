package com.lti.cc;

public class INR implements Currency {

	@Override
	public double dollarValue() {
		return 70.50;
	}

}
