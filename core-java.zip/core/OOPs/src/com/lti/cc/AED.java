package com.lti.cc;

public class AED implements Currency {

	@Override
	public double dollarValue() {
		return 3.70;
	}

}
