package com.lti.picture;

public interface MoviePrice {
 double  price();
	

}
