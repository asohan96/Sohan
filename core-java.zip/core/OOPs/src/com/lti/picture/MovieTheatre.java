package com.lti.picture;

public class MovieTheatre {
private String name;
private int noofseats;
private double time;
private double total=0;
public MovieTheatre(String name, int noofseats, int time) {
	
	this.name = name;
	this.noofseats = noofseats;
	this.time = time;
}

public void Ticket()
{
	//total=Simba.price()*noofseats;
	System.out.println("TOTAL :"+total);
}

}
