package com.lti.picture;

public class Simba implements MoviePrice{

	@Override
	public double price() {
	
		return 150;
	}
	

}
