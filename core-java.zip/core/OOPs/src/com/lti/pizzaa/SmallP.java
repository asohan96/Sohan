package com.lti.pizzaa;


public class SmallP implements Size {

	@Override
	public double sizeVal() {
		return 300;
	}

}
