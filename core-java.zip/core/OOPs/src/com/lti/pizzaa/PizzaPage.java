package com.lti.pizzaa;


public class PizzaPage {
	private Size size;
	private Type type;
	private Toppings[] topings;
	private double total=0;
	private double toptotal = 0;

	public PizzaPage(Size size, Type type, Toppings...t1) {
		this.size = size;
		this.type = type;
		this.topings = t1;
	}

	public void Bill() {

		
		for (Toppings t : topings)
			toptotal += t.topVal();

		total = size.sizeVal() + type.Tprice() + toptotal;
		System.out.println(total);
	}
}
