package com.lti.pizzaa;


public interface Type {
double Tprice();
}
