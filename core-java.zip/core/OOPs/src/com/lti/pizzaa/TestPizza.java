package com.lti.pizzaa;

import java.util.*;

public class TestPizza {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Cheese c = new Cheese();
		paparoni p = new paparoni();

		VegP vtp = new VegP();
		NonVegP ntp = new NonVegP();

		SmallP s = new SmallP();
		LargeP l = new LargeP();

		PizzaPage pi = new PizzaPage(s, ntp, c);
		pi.Bill();
		PizzaPage pj = new PizzaPage(s, vtp, c, p);
		pj.Bill();

	}

}
