package com.lti.pizzaa;


public class LargeP implements Size {

	@Override
	public double sizeVal() {
		return 500;
	}

}
