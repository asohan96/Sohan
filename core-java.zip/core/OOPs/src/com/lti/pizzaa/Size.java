package com.lti.pizzaa;


public interface Size {
double sizeVal();
}
