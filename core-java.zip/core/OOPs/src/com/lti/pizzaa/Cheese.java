package com.lti.pizzaa;


public class Cheese implements Toppings {

	@Override
	public double topVal() {
		return 120;
	}

}
