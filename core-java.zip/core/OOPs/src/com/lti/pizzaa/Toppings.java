package com.lti.pizzaa;


public interface Toppings {
	double topVal();
}
