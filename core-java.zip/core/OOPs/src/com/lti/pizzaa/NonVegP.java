package com.lti.pizzaa;


public class NonVegP implements Type {

	@Override
	public double Tprice() {
		return 150;
	}

}
