package com.lti.pizzaa;


public class paparoni implements Toppings {

	@Override
	public double topVal() {
		return 60;

	}

}
