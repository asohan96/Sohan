package com.lti.pizzaa;


public class VegP implements Type {

	@Override
	public double Tprice() {
		
		return 50;
	}

}
