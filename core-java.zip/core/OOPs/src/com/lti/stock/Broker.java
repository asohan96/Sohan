package com.lti.stock;

public interface Broker extends Holder{
void getQuote();
}
