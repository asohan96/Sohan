package com.lti.stock;

public interface Exchange extends Broker{
void setQuote();
}
