package com.lti.bank;

public class CustomerDetails {
	private int custId;
	private String custName;
	private int creditLimit;
	public CustomerDetails() {
		this(101,"SOHAN",650);
	}
	public CustomerDetails(int custId, String custName, int creditLimit) {
		
		this.custId = custId;
		this.custName = custName;
		this.creditLimit = creditLimit;
	}
	
	public void display()
	{
		System.out.println("\n\nCUSTOMER_ID : "+custId+"\n CUSTOMER_NAME : "+custName+"\nCREDIT_LIMIT : "+creditLimit);
	}
	
	public static void main(String[] args) {
		CustomerDetails c1=new CustomerDetails();
		c1.display();
		
		CustomerDetails c2=new CustomerDetails(201,"TANUJA",850);
		c2.display();
	}
}
