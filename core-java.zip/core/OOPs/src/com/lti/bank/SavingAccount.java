package com.lti.bank;

public class SavingAccount extends AccountDetails {

	public SavingAccount() {
		
		
	}
	
	

	//@Override
	public void withdraw(double amount) throws BalanceException {
		 if(amount<=(balance-MIN_SAV_BAL)) {
		 balance-=amount;
		 txns[idx++]=new Transaction("DR",amount,balance);
			
		 }
		else
			throw new BalanceException("INSUFFICIENT FUNDS...");
	//		System.out.println("NO FUNDS!");
	}



	public SavingAccount(String holder) {
		super(holder, MIN_SAV_BAL);
		txns=new Transaction[10];
		txns[idx++]=new Transaction("CR",MIN_SAV_BAL,MIN_SAV_BAL);
		/*Transaction t=new Transaction("CR",MIN_SAV_BAL,MIN_SAV_BAL);
		txns[idx]=t;
		idx++;
		*/
	}

}
