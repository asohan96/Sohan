package com.lti.bank;

public class CurrentAccount extends AccountDetails  {
//varibales declared
	private double overdraft;
	//constructors
	public CurrentAccount() {
		
		
	}
//para constr
	public CurrentAccount(String holder) {
		super(holder, INIT_CURR_BAL);
		this.overdraft=OD_LIMIT;
	}
//methods
	//@Override
	public void summary() {
		super.summary();
		System.out.println("overdraft : " + overdraft);
		
	}

	//@Override
	public void deposit(double amount) {
		overdraft+=amount;
		if(overdraft>OD_LIMIT)
		{
			balance+=(overdraft-OD_LIMIT);
			overdraft=OD_LIMIT;
		}
	}
		/*if(overdraft==10000)
		{
			balance+=amount;
		}
		else if(balance<5000&&overdraft<10000)
		{
			overdraft+=amount;
			if(overdraft>10000)
				balance=overdraft-10000;
		}
		*/
	
	

	//@Override
	public void withdraw(double amount) throws BalanceException 
		 /*if(amount<=balance  overdraft>=amount )
				 {
			 balance-=amount;
				 }
		 
		 else if(amount<=overdraft && amount>balance)
				 	{
			 			balance=0;
				 		overdraft -=amount;
				 	}
			 
		else
			System.out.println("NO FUNDS!");
	}*/
	{
		if(amount<(overdraft+balance))
		{
			balance-=amount;
			if(balance<MIN_CURR_BAL)
			{
				overdraft+=balance;
				balance=MIN_CURR_BAL;
			}
			
		}
		else
throw new BalanceException("INSUFFICIENT FUNDS...");
//		System.out.println("INSUFFICIENT FUNDS.");
	}
}
	


