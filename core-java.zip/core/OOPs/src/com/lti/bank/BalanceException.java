package com.lti.bank;

public class BalanceException extends Exception {

	public BalanceException() {
		super();
		
	}

	public BalanceException(String msg) {
		super(msg);
		
	}

}
