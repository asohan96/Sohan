package com.lti.bank;

public interface Bank {
void summary();
void deposit(double amount);
void withdraw(double amount) throws BalanceException;
void statement();
//constants
 int INIT_ACCNT_NO = 12001;
 double INIT_CURR_BAL = 5000;
 double MIN_CURR_BAL = 0;
 double MIN_SAV_BAL = 1000;
double OD_LIMIT = 10000;
	
}
