package com.lti.emp;

public class Manager extends Employee{
private double incentive;

public Manager() {

}

public Manager(String empName, double salary, double inc) {
	super(empName, salary);
	incentive=inc;
	}

@Override
public double getSalary() {
	
	return super.getSalary()+incentive;
}

@Override
public void payslip() {
	
	super.payslip();
	System.out.println("INCENTIVE : " + incentive);
}

	
}
