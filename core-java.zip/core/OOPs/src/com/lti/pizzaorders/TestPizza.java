package com.lti.pizzaorders;


public class TestPizza {
	public static void main(String[] args) {
	PizzaOrder vp=new PizzaOrder("veg", "small", 2, "tomato","capsicum");
	System.out.println("-----------------------------------------");
	PizzaOrder nvp=new PizzaOrder("nonveg", "medium", 1, "barbequechicken","extracheese");
	
	}
}
