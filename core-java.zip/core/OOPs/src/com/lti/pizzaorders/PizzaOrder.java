package com.lti.pizzaorders;

public class PizzaOrder {
	private String type;
	private String size;
	private String[] toppings = { "capsicum", "tomato", "butterchicken", "barbeque-chicken", "extra-cheese" };
	private int quantity;
	private int total=0;

	public PizzaOrder(String type, String size, int quantity, String... toppings) {
		int i = 0;
		this.type = type;
		this.size = size;
		this.toppings = toppings;
		this.quantity = quantity;
		if (type == "veg") {
			if (size == "small")
				total = total + 100;
			else if (size == "medium")
				total = total + 120;
			else
				total = total + 150;
		}
		if (type == "nonveg") {
			if (size == "small")
				total = total + 110;
			else if (size == "medium")
				total = total + 130;
			else
				total = total + 160;

		}
		for (i=0; i < toppings.length; i++) {
			if (type == "veg" && (toppings[i] == "tomato" && toppings[i]=="capsicum"))
				total += 150;
			else
			total += 100;
		}
		/*if (type == "veg" && (topping == "tomato" && t1=="capsicum"))
		for(String t1:toppings)
		{
			
				total += 150;
		else
			total += 100;
		}*/
			for (i = 0; i < toppings.length; i++) {
				if (type == "nonveg" && (toppings[i] == "barbequechicken" && toppings[i]=="butterchicken"))
					total += 180;
				else
				total += 80;
			}
			if(quantity>1)
			total=total*quantity;
System.out.println("BILL : \nPIZZA TYPE : "+type+"\nSIZE : "+size+"\nQUANTITY : "+quantity);
for(String top:toppings)

System.out.println("\nTOPPINGS : "+top);

System.out.println("\nTOTAL : "+total);
		}

}


