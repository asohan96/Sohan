package com.lti.pizza;

public class ToppingCapsicumm implements Topping{
	public double Order()
	{
		return 50;
	}
	
}
