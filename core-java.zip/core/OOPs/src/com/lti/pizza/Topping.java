package com.lti.pizza;

public interface Topping {
	
		public double Order();

	}


