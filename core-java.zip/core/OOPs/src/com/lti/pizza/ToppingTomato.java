package com.lti.pizza;

public class ToppingTomato implements Topping{

	@Override
	public double Order() {
		
		return 30;
	}

}
