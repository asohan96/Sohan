package com.lti.pizza;

public class PizzaOrder {

}
