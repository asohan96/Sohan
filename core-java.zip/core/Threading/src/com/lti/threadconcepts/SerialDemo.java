package com.lti.threadconcepts;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerialDemo {

	public static void main(String[] args) throws Exception {
		Person p=new Person("POLO",21);
System.out.println(p);
String path="D:/stuser/tanuja/tanu.dat";
FileOutputStream fps=new FileOutputStream(path);//writing data to file  
ObjectOutputStream ostream=new ObjectOutputStream(fps);//SERIALIZATION to file
ostream.writeObject(p);
ostream.close();

System.out.println("DESERIALIZATION");
							//						DESERIALIZATION
ObjectInputStream istream= new ObjectInputStream(new FileInputStream(path));
Object dp=istream.readObject();
System.out.println(dp);
istream.close();
	}

}
