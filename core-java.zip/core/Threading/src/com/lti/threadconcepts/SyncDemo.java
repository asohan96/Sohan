package com.lti.threadconcepts;

public class SyncDemo implements Runnable {

	@Override
	public synchronized void run() {
		String name = Thread.currentThread().getName();
		Display(name);

	}

	private void Display(String name) {
		System.out.println(name + " ENTERED DISPLAY..");
		synchronized (this) {

			try {
				System.out.print("[");
				Thread.sleep(100);
				System.out.print(name);

				Thread.sleep(100);
				System.out.println("]");
			}

			catch (InterruptedException e) {
				e.printStackTrace();
			}
		} 
	}

	public static void main(String[] args) {
		SyncDemo sd = new SyncDemo();
		Thread t1 = new Thread(sd, "ALPHA");
		Thread t2 = new Thread(sd, "BETA");
		Thread t3 = new Thread(sd, "GAMA");
		t1.start();
		t2.start();
		t3.start();
	}

}
